# Rfunk

A collection of useful R functions.

## Installation

You can install the development version of r_funk from GitHub with:

```r
# install.packages("devtools")
devtools::install_github("SemiQuant/r_funk", build_vignettes = TRUE)
```

## Usage

See the vignettes.

```r
require(Rfunk)
browseVignettes("Rfunk")
```
