## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE,
  fig.width = 7,
  fig.height = 5,
  eval = TRUE
)
library(ggplot2)

## -----------------------------------------------------------------------------
# install.packages("devtools")
devtools::install_github("SemiQuant/r_funk")

## -----------------------------------------------------------------------------
library(Rfunk)
data(example_qpcr_data, package = "Rfunk")
data(example_gene_expr, package = "Rfunk")
data(example_gene_list, package = "Rfunk")

## -----------------------------------------------------------------------------
# Run qPCR analysis
results <- analyze_pcr(
  data = example_qpcr_data,
  ct_col = "Cq",
  sample_col = "Sample",
  target_col = "Target",
  target = "Target_Gene",
  reference_sample = "Control",
  reference_target = "Reference_Gene"
)

## -----------------------------------------------------------------------------
# Note: This requires a DESeqDataSet object from DESeq2
# For demonstration, we'll show how to use the function
# with example data (this would normally be your actual DESeq2 results)

# Example usage with DESeq2 object:
# outliers <- detect_outliers(dds)
# outliers <- detect_outliers(dds, group_col = "condition")

# The function returns a list with:
# - mad_outliers: outliers based on MAD distances
# - cook_outliers: outliers based on Cook's distances  
# - correlation_outliers: outliers based on correlation
# - all_outliers: combined list of all outliers

## -----------------------------------------------------------------------------
# Perform GO analysis
go_results <- perform_go_analysis(
  results_df = example_gene_expr,
  title = "Example GO Analysis",
  p_cutoff = 0.05,
  genome = "hsa"
)

# Perform KEGG analysis
kegg_results <- perform_kegg_analysis(
  results_df = example_gene_expr,
  title = "Example KEGG Analysis",
  genome = "hsa"
)

# Perform MSigDB analysis
msig_results <- perform_mSig_analysis(
  results_df = example_gene_expr,
  title = "Example MSigDB Analysis",
  genome = "hsa"
)

## -----------------------------------------------------------------------------
# Note: This requires a MultiQC flagstat file from your sequencing analysis
# Example usage (replace with your actual file path):

# Basic dual-genome sequencing analysis
# dualseq_results <- analyze_dual_seq(
#   flagstat_file = "path/to/multiqc_samtools_flagstat.txt",
#   primary_genome = "human",
#   secondary_genome = "mtb",
#   control_sample = "posControl"
# )

# Analysis excluding specific samples
# dualseq_results <- analyze_dual_seq(
#   flagstat_file = "path/to/multiqc_samtools_flagstat.txt",
#   primary_genome = "human",
#   secondary_genome = "mtb",
#   control_sample = "posControl",
#   exclude_samples = c("negControl", "blank", "water")  # Exclude negative controls and blanks
# )

# Access individual plots
# dualseq_results$alignment_summary    # Shows distribution of reads between genomes
# dualseq_results$enrichment          # Shows enrichment relative to control
# dualseq_results$combined_plot       # Shows both plots combined

# Save plots to HTML files
# dualseq_results <- analyze_dual_seq(
#   flagstat_file = "path/to/multiqc_samtools_flagstat.txt",
#   primary_genome = "human",
#   secondary_genome = "mtb",
#   control_sample = "posControl",
#   output_dir = "path/to/output",
#   save_plots = TRUE
# )

## -----------------------------------------------------------------------------
# Note: These functions require DESeq2 objects for volcano plots
# For demonstration purposes, we'll show the function signatures:

# Create a basic volcano plot (requires DESeq2 object)
# volcano_plot <- create_volcano_plot(dds, title = "My Volcano Plot")

# Create an interactive volcano plot (requires DESeq2 object)  
# interactive_volcano <- create_interactive_volcano_plot(dds, title = "Interactive Volcano")

# Create an interactive datatable
dt <- create_interactive_datatable(
  df = example_gene_expr,
  caption_text = "Gene Expression Results"
)

## -----------------------------------------------------------------------------
# Create toy data for demonstration
toy_data <- create_toy_volcano_data(n_genes = 1000, n_sig = 100)
head(toy_data)

# Basic volcano plot
p1 <- volcano_plot(toy_data)
print(p1)

# Custom thresholds
p2 <- volcano_plot(toy_data, 
                   padj_threshold = 0.01, 
                   effect_size_threshold = 1.5)

# Annotate more genes
p3 <- volcano_plot(toy_data, num_annotate = 20)

# Add a title
p4 <- volcano_plot(toy_data, title = "My Differential Expression Analysis")

# Get the processed data instead of plot
volcano_data <- volcano_plot(toy_data, make_plot = FALSE)
head(volcano_data)

# Use with custom column names
# If your data has different column names, you can specify them:
# p5 <- volcano_plot(my_data, 
#                    id_col = "gene_id",
#                    pvalue_col = "pval",
#                    padj_col = "fdr",
#                    logfc_col = "logFC")

## -----------------------------------------------------------------------------
# Create toy enrichment data
toy_enrichment <- create_toy_enrichment_data(n_pathways = 20)
head(toy_enrichment)

# Basic enrichment plot (interactive)
p_enrich1 <- enrichment_plot(toy_enrichment)
print(p_enrich1)
# Note: This creates an interactive plotly plot - hover over points to see details!

# Show only top 10 pathways
p_enrich2 <- enrichment_plot(toy_enrichment, top_n = 10)

# Use light theme instead of dark
p_enrich3 <- enrichment_plot(toy_enrichment, dark_theme = FALSE)

# Custom title
p_enrich4 <- enrichment_plot(toy_enrichment, 
                             title = "GO Term Enrichment Analysis",
                             top_n = 15)

# Use with custom column names
# If your enrichment data has different column names:
# p_enrich5 <- enrichment_plot(my_enrichment_data,
#                              description_col = "pathway",
#                              pvalue_col = "pvalue",
#                              count_col = "gene_count")

## -----------------------------------------------------------------------------
# Create smaller dataset
small_data <- create_toy_volcano_data(n_genes = 100, n_sig = 20, seed = 456)

# Create more pathways
large_enrichment <- create_toy_enrichment_data(n_pathways = 50, seed = 789)
enrichment_plot(large_enrichment, top_n = 20)

## -----------------------------------------------------------------------------
# Step 1: Create or load your differential expression data
de_data <- create_toy_volcano_data()

# Step 2: Create volcano plot
vol_plot <- volcano_plot(de_data, 
                         padj_threshold = 0.05,
                         effect_size_threshold = 2,
                         num_annotate = 15,
                         title = "Differential Expression Analysis")

# Step 3: Save the plot
ggsave("volcano_plot.pdf", vol_plot, width = 8, height = 6)

# Step 4: Create or load enrichment results
enrich_data <- create_toy_enrichment_data()

# Step 5: Create interactive enrichment plot
enrich_plot <- enrichment_plot(enrich_data,
                               top_n = 20,
                               title = "Pathway Enrichment Analysis")

# Step 6: Save interactive plot as HTML
htmlwidgets::saveWidget(enrich_plot, "enrichment_plot.html")

## -----------------------------------------------------------------------------
?analyze_pcr
?perform_go_analysis
?create_volcano_plot
?volcano_plot
?enrichment_plot

